import sqlite3
import functools
import traceback
import psycopg2
import json
import io
import csv

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for, Response
)
from werkzeug.security import check_password_hash, generate_password_hash

from dashboard.db import get_db

db_params = {
    'host': '149.165.170.117',
    'port': 5432,
    'database': 'duodatabase',
    'user': 'exouser',
    'password': 'your_password',
}

bp = Blueprint('dashboard', __name__)


@bp.route('/')
def index():
    return render_template('base.html')


@bp.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None

        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
        elif db.execute(
                'SELECT id FROM user WHERE username = ?', (username,)
        ).fetchone() is not None:
            error = 'User {} is already registered.'.format(username)

        if error is None:
            db.execute(
                'INSERT INTO user (username, password) VALUES (?, ?)',
                (username, generate_password_hash(password))
            )
            db.commit()
            return redirect(url_for('dashboard.login'))

        flash(error)

    return render_template('auth/register.html')


@bp.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = ?', (username,)
        ).fetchone()

        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'

        if error is None:
            session.clear()
            session['user_id'] = user['id']
            return redirect(url_for('dashboard.index'))

        flash(error)
    return render_template('auth/login.html')


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')

    if user_id is None:
        g.user = None
    else:
        g.user = get_db().execute(
            'SELECT * FROM user WHERE id = ?', (user_id,)
        ).fetchone()


@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('dashboard.index'))


def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('dashboard.login'))

        return view(**kwargs)

    return wrapped_view


@bp.route('/profile')
@login_required
def profile():
    return render_template('auth/profile.html')


@bp.route('/dashboard')
@login_required
def dashboard():
    return render_template('view/dashboard.html')

@login_required
@bp.route('/fetch_data')
def fetch_data():
    timestamp = request.args.get('timestamp','')
    data = []
    try:
        connection = psycopg2.connect(**db_params)
        cursor = connection.cursor()
        # 构建 SQL 查询语句，根据时间戳检索数据
        query = "SELECT data_receive_time as time, value FROM datatestv2 WHERE data_receive_time > %s"
        cursor.execute(query, (timestamp,))
        data = cursor.fetchall()
    except psycopg2.Error as e:
        print("Database error:", e)
        data = []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
    # data = [{'time':'2022-01-01','value': 2.3}]
    new_data = []   
    for d in data:
         new_data.append({'time':str(d[0]),'value': d[1]})        
    response = json.dumps(new_data)
    return response,200,{"Content-Type":"application/json"}


@login_required
@bp.route('/metadata', methods=['GET', 'POST'])
# @login_required
def metadata():
    page = int(request.args.get('page', 1))
    per_page = 15
    user_study_id = request.args.get('study_id','')
    selected_sensors = request.args.get('selected_sensors','')
    if request.method == 'POST':
        if request.form.get("study_id") is not None:
            user_study_id = request.form['study_id']
        form_getlist = request.form.getlist("selected_sensors")
        if form_getlist is not None and form_getlist.__len__() > 0:
            selected_sensors = request.form.getlist('selected_sensors')
        data, total_pages, total = query_database(user_study_id, selected_sensors, page, per_page)
        selected_sensors = ','.join(selected_sensors)
    else:
        # 接收3个参数，返回两个
        if selected_sensors != '':
            sensors = selected_sensors.split(',')
        else:
            sensors = []
        data, total_pages, total = query_database(user_study_id, sensors, page, per_page)

    return render_template('view/metadata.html', data=data, page=page, total_pages=total_pages,
                           total=total, page_size=per_page, 
                           study_id=user_study_id,
                           selected_sensors=selected_sensors)


def generate_csv(data):
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['id', 'study_id', 'sensor_id', 'value', 'timestamp'])  # Add column headers
    for row in data:
        writer.writerow(row)
    return output.getvalue()
    
def query_database(user_study_id, selected_sensors, page, per_page):
    try:
        connection = psycopg2.connect(**db_params)
        cursor = connection.cursor()

        param = []
        metadata_sql = 'SELECT * FROM datatestv2 where 1=1 '
        if user_study_id is not None and user_study_id != '':
            metadata_sql = metadata_sql + 'and study_id = %s '
            param.append(user_study_id)
        if selected_sensors is not None and selected_sensors != '' and selected_sensors.__len__() > 0:
            metadata_sql = metadata_sql + 'and sensor_id IN %s '
            param.append(tuple(selected_sensors))

        # descending order
        metadata_sql = metadata_sql + 'ORDER BY data_receive_time DESC'
        
        count_query = "SELECT COUNT(*) FROM (%s) b " % metadata_sql
        cursor.execute(count_query, param)
        total_rows = cursor.fetchone()[0]
        total = total_rows

        plus = 0
        if total % per_page > 0:
            plus = 1

        total_pages = int(total / per_page) + plus
        offset = (page - 1) * per_page

        session['metadata_dl'] = {
            'query': metadata_sql,
            'params': param.copy()
        }

        param.append(per_page)
        param.append(offset)
        
        metadata_sql = metadata_sql + " LIMIT %s OFFSET %s"
        cursor.execute(metadata_sql, param)
        data = cursor.fetchall()
        return data, total_pages, total

    except psycopg2.Error as e:
        traceback.print_exc()
        return [], 0, 0

    finally:
        # 关闭游标和连接
        if 'cursor' in locals() and cursor is not None:
            cursor.close()
        if 'connection' in locals() and connection is not None:
            connection.close()

@login_required
@bp.route("/download")
def download():
    metadata_dl = session.get('metadata_dl')
    if metadata_dl is None:
        return "No metadata to download", 404


    query = metadata_dl['query']
    params = metadata_dl['params']
    try:
        connection = psycopg2.connect(**db_params)
        cursor = connection.cursor()
        cursor.execute(query, params)
        data = cursor.fetchall()
        csv = generate_csv(data)
        return Response(
            csv,
            mimetype="text/csv",
            headers={"Content-disposition":
                     "attachment; filename=metadata.csv"})
    except psycopg2.Error as e:
        traceback.print_exc()
        return "Error downloading metadata", 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

@login_required
@bp.route("/storageDashboard")
def storageDashboard():
    return render_template('view/storageDashboard.html')