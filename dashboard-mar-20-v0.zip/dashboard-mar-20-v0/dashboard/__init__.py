import os
from flask import Flask
import paho.mqtt.client as mqtt
import sqlite3
import json
import math

from dashboard.routes import bp

app = Flask(__name__, instance_relative_config=True)

@app.context_processor
def inject_max():
    return {'max': max}

@app.context_processor
def inject_min():
    return {'min': min}


@app.context_processor
def inject_ceil():
    return {'ceil': math.ceil}

app.config.from_mapping(
    SECRET_KEY='dev',
    
    # db file is in the parent directory
    DATABASE=os.path.join(os.path.dirname(app.instance_path), 'your_database.db'),
)

try:
    os.makedirs(app.instance_path)
except OSError:
    pass


app.register_blueprint(bp)


# create user table
db_path = "./your_database.db"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

command = """CREATE TABLE IF NOT EXISTS user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL);"""
            
cursor.execute(command)
